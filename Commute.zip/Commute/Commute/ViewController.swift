//
//  ViewController.swift
//  Commute
//
//  Created by Amjad Alharbi on 10/19/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
// Should be miles_input
    @IBOutlet weak var time_input: UITextField!
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var gas_tank: UILabel!
    @IBOutlet weak var switch_outlet: UISwitch!
    
    var totalGas : Double = 24
    var totalTime : Double = 0
    var m_speed : Double = 20
    var montly : Double = 1
    
    @IBOutlet weak var total_time: UILabel!
    
    
    @IBOutlet weak var total_gas: UILabel!
    
    
    @IBAction func slider_act(_ sender: UISlider) {
        let gas_in_tank=sender.value //float
        
        gas_tank.text=String(format: "Gas in tank %.2f gallons", gas_in_tank) //convert float to String

    }
    
    
    @IBAction func switch_act(_ sender: UISwitch) {
        if switch_outlet.isOn{
          montly = 20
         
        }
        else{
          montly = 1
        }
    }
    
    
    @IBOutlet weak var seg_outlet: UISegmentedControl!
    
    
    @IBAction func seg_act(_ sender: UISegmentedControl) {
        if seg_outlet.selectedSegmentIndex==0{
          m_speed = 20
            totalGas = 24
            img.image = UIImage(named: "car")
            
            var miles: Double = 0
            if time_input.text!.isEmpty{
                miles = 0
                
            }
                
            else{
                miles = Double(time_input.text!)!
            }
            calc_time_gas(miles: miles, speed: m_speed, gas: totalGas)
            
            let alert = UIAlertController(title: "Carpool", message: "Do you want to carpool?", preferredStyle: .alert)
            let okAction=UIAlertAction(title: "No", style:UIAlertActionStyle.cancel, handler: nil)
            alert.addAction(okAction) //adds the alert action to the alert object
            present(alert, animated: true, completion: nil)
        }
        else if seg_outlet.selectedSegmentIndex==1{
            var miles: Double = 0
            if time_input.text!.isEmpty{
                miles = 0
            }
                
            else{
                miles = Double(time_input.text!)!
            }
            
            m_speed = 12
            let time = (miles/m_speed) * 60 + 5*2
            let gas_amount = 0
            total_time.text = String(format:"%.2f mins" , time)
            total_gas.text = String(format:"%.2f gallons" , gas_amount)
            img.image = UIImage(named: "bus")
            

            
        }
        else if seg_outlet.selectedSegmentIndex==2{
            var miles: Double = 0
            if time_input.text!.isEmpty{
                miles = 0
            }
                
            else{
                miles = Double(time_input.text!)!
            }
            m_speed  = 10
            
            let time = (miles/m_speed) * 60
            let gas_amount = 0
            total_time.text = String(format:"%.2f mins" , time)
            total_gas.text = String(format:"%.2f gallons" , gas_amount)
            
            img.image = UIImage(named: "bike")
            
          
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    func calc_time_gas(miles: Double, speed : Double , gas: Double){
        let time = (miles/speed) * 60 * montly
        let gas_amount = (miles/gas) * montly
        total_time.text = String(format:"%.2f mins" , time)
        total_gas.text = String(format:"%.2f gallons" , gas_amount)
        
    }
    
    
    @IBAction func commute_button(_ sender: UIButton) {
    
            var miles: Double = 0
            if time_input.text!.isEmpty{
                miles = 0
            }
                
            else{
                miles = Double(time_input.text!)!
            }
            calc_time_gas(miles: miles, speed: m_speed, gas: totalGas)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        time_input.delegate=self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

