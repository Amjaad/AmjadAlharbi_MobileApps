//
//  Recommender.swift
//  Tenki
//
//  Created by Amjad Alharbi on 10/16/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import Foundation
class Recommender{
    
    func advice(precipTyp:String,temp_max : Double, temp_min: Double, humidity: Int, windSpeed: Double) -> String{
        if precipTyp == "Rain"{
            return "You may want  to take an umbrella\n, since rain is expected"
    }
        else if precipTyp == "Snow" {
            return "You may want to wear a coat\n, hat and gloves as wel"
        }
        else if temp_max-temp_min>=30{
            return "The temperature will change \n significantly so plan accordingly"
        }
        else if humidity<30{
            return "It will be very dry,\n so stay hydrated"
        }
    return precipTyp
 }
}
