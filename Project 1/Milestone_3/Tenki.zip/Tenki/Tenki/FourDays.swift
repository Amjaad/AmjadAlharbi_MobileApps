//
//  FourDays.swift
//  Tenki
//
//  Created by Amjad Alharbi on 10/14/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import Foundation
// Send request to API and parse response by calling Weather()
class FourDays {
    
    private let openWeatherMapBaseURL = "https://api.openweathermap.org/data/2.5/forecast/daily"
    private let openWeatherMapAPIKey = "364905a321944dc78a0f61f41d66580b"
    func getWeather(city: String , completion:@escaping ([Forecast]?) -> () ) {
        
        let session = URLSession.shared
        let weatherRequestURL = URL(string: "\(openWeatherMapBaseURL)?APPID=\(openWeatherMapAPIKey)&q=\(city)&cnt=5")!
        // The data task retrieves the data.
        let task = session.dataTask(with: weatherRequestURL) {
            (data, response,error) in
            // check for any errors
            guard error == nil else {
                print("error calling GET on /todos/1")
                return
            }
            // make sure we got data
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            var forecastData : [Forecast] = []
            // parse the result as JSON, since that's what the API provides
            do {
                if let todo = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: AnyObject]{
                    if let dailyData = todo["list"] as? [[String: AnyObject]]{
                        for day in dailyData{
                       forecastData.append(Forecast(weatherData: day))
                            
                        }
                    }
                  
                   
                }
                
            } catch  {
                print("error trying to convert data to JSON")
                return
            }
            
            completion(forecastData)
            
        }
        
        task.resume()
        
    }
    
}
