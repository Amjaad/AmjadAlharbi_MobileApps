//
//  FirstViewController.swift
//  Tenki
//
//  Created by Amjad Alharbi on 10/4/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    
   
    @IBOutlet weak var descrp: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var currentTemp: UILabel!
    @IBOutlet weak var feelsLike: UILabel!
    @IBOutlet weak var humidity: UILabel!
    @IBOutlet weak var windSpeed: UILabel!
    @IBOutlet weak var maxMin: UILabel!
    @IBOutlet weak var recommend: UILabel!
    
    @IBOutlet weak var mcity: UILabel!
    override func viewDidLoad() {
        
        let currentWeather = WeatherGetter()
        updateForecast(current_forecast: currentWeather)
      
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func updateForecast(current_forecast: WeatherGetter){
        let loc = "Boulder"
        current_forecast.getWeather(city: loc) { (mresults) in
            if mresults != nil {
                DispatchQueue.main.async {
                let results = mresults
                
                self.mcity.text = results!.city

                self.descrp.text = results!.weatherDescription
                self.img.image = UIImage(named: results!.weatherIconID)
                self.currentTemp.text=String(format: "%.0f°",results!.temp)
                
//                Details
                self.maxMin.text="↑"+String(format: "%.0f°",results!.temp_max)+" ↓"+String(format: "%.0f°",results!.temp_min)

                self.humidity.text="Humidity: "+String(results!.humidity)+"%"
                self.feelsLike.text="Feels Like: "+String(format: "%.0f°",results!.temp)
                self.windSpeed.text="Wind: "+String(format: "%.0f mph",results!.windSpeed)
                self.recommend.text=Recommender().advice(precipTyp: results!.mainWeather, temp_max:results!.temp_max, temp_min: results!.temp_min, humidity: results!.humidity, windSpeed:results!.windSpeed )+"\n"
                print(results!)
                }
            }
            else{
                print("Failed to get data")
            }
        }
    }


}

