//
//  Forecast.swift
//  Tenki
//
//  Created by Amjad Alharbi on 10/14/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import Foundation
struct Forecast {
    
    let dateAndTime: Date
    
    
    let weatherID: Int
    let mainWeather: String
    let weatherDescription: String
    let weatherIconID: String
    
    // OpenWeatherMap reports temperature in Kelvin,
    // which is why we provide celsius and fahrenheit
    // computed properties.
    var temp_max: Double
    var temp_min: Double
    
    let humidity: Int
    
    let windSpeed: Double
    
    // These properties are optionals because OpenWeatherMap doesn't provide:
    // - a value for wind direction when the wind speed is negligible
    // - rain info when there is no rainfall
    
    
    
    init(weatherData: [String: AnyObject]) {
        dateAndTime = Date(timeIntervalSince1970: weatherData["dt"] as! TimeInterval)
        
        let tempDict = weatherData["temp"] as! [String: Any]
        temp_max = tempDict["max"] as! Double
        temp_max = (temp_max - 273.15) * 1.8 + 32
        temp_min = tempDict["min"] as! Double
        temp_min = (temp_min - 273.15) * 1.8 + 32
        
        
        let weatherDict = weatherData["weather"]![0] as! [String: Any]
        weatherID = weatherDict["id"] as! Int
        mainWeather = weatherDict["main"] as! String
        weatherDescription = weatherDict["description"] as! String
        weatherIconID = weatherDict["icon"] as! String
        
        
        
        humidity = weatherData["humidity"] as! Int
    
        windSpeed = weatherData["speed"] as! Double
     
        
        
        
        
        
        
    }
    
}
