//
//  SecondViewController.swift
//  Tenki
//
//  Created by Amjad Alharbi on 10/4/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var img4: UIImageView!
    
    @IBOutlet weak var temp1: UILabel!
    @IBOutlet weak var temp3: UILabel!
    @IBOutlet weak var temp2: UILabel!
    @IBOutlet weak var temp4: UILabel!
    
    
    @IBOutlet weak var rec1: UILabel!
    @IBOutlet weak var rec2: UILabel!
    @IBOutlet weak var rec3: UILabel!
    @IBOutlet weak var rec4: UILabel!
    
    
    override func viewDidLoad() {
        let weather = FourDays()
        let loc = "Boulder"
        weather.getWeather(city: loc) { (results:[Forecast]?)  in
            if let dailyforecast = results {
                self.updateForecast(forecast: dailyforecast[1], img: self.img1, tempRange: self.temp1, recommend: self.rec1)
                  self.updateForecast(forecast: dailyforecast[2], img: self.img2, tempRange: self.temp2, recommend: self.rec2)
                  self.updateForecast(forecast: dailyforecast[3], img: self.img3, tempRange: self.temp3, recommend: self.rec3)
                  self.updateForecast(forecast: dailyforecast[4], img: self.img4, tempRange: self.temp4, recommend: self.rec4)
               
            }
        }
        
        super.viewDidLoad()
        // Do any   additional setup after loading the view, typically from a nib.
    }
  
 

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func updateForecast(forecast: Forecast, img: UIImageView!, tempRange: UILabel!, recommend: UILabel!){
        DispatchQueue.main.async {
        img.image=UIImage(named: forecast.weatherIconID)
        tempRange.text="↑ "+String(format: "%.0f°",forecast.temp_max)+" ↓"+String(format: "%.0f°", forecast.temp_min)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        recommend.text=dateFormatter.string(from: forecast.dateAndTime)+"\n "+Recommender().advice(precipTyp: forecast.mainWeather, temp_max: forecast.temp_max, temp_min: forecast.temp_min, humidity: forecast.humidity, windSpeed:forecast.windSpeed)
        }
        
    }


}

