//
//  Recommender.swift
//  Tenki
//
//  Created by Amjad Alharbi on 10/16/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import Foundation
class Recommender{
    
}
