package com.atlas.amjad.gradetracker;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                getAvgGrade();
            }
        });

        final Button restButton = findViewById(R.id.rest_button);
        restButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
              restFields();
            }
        });
    }
    public void getAvgGrade(){

        Spinner hw_spinner = (Spinner) findViewById(R.id.hw_spinner);
        EditText hw_grade = (EditText)findViewById(R.id.hw_grade);

        Spinner quizzes_spinner = (Spinner) findViewById(R.id.quizzes_spinner);
        EditText quizzes_grade = (EditText)findViewById(R.id.quizzes_grade);

        Spinner project_spinner = (Spinner) findViewById(R.id.project_spinner);
        EditText project_grade = (EditText)findViewById(R.id.project_grade);

        Spinner final_spinner = (Spinner) findViewById(R.id.final_spinner);
        EditText final_grade = (EditText)findViewById(R.id.final_grade);

        ImageView grade_letter_img = (ImageView) findViewById(R.id.imageView);
        final TextView avg_grade = (TextView) findViewById(R.id.avg_grade);

        Switch extr_credit = (Switch) findViewById(R.id.extra);
        double hw;
        double qs;
        double project;
        double final_exam;
        if(hw_grade.getText().toString().isEmpty() ){
            hw=0;
        }
        else{
            hw=Double.parseDouble(hw_grade.getText().toString());
        }
        if (quizzes_grade.getText().toString().isEmpty()){
            qs=0;
        }
        else{
            qs=Double.parseDouble(quizzes_grade.getText().toString());
        }
        if (project_grade.getText().toString().isEmpty()){
            project=0;
        }
        else {
            project=Double.parseDouble(project_grade.getText().toString());
        }
        if (final_grade.getText().toString().isEmpty()){
            final_exam=0;
        }
        else {
            final_exam=Double.parseDouble(final_grade.getText().toString());
        }
        double hw_w=Double.parseDouble(String.valueOf(hw_spinner.getSelectedItem()));
        double q_w = Double.parseDouble(String.valueOf(quizzes_spinner.getSelectedItem()));
        double project_w=Double.parseDouble(String.valueOf(project_spinner.getSelectedItem()));
        double final_w= Double.parseDouble(String.valueOf(final_spinner.getSelectedItem()));

        hw= hw_w/100 *hw;
        qs= q_w/100*qs;
        project= project_w/100*project;
        final_exam= final_w/100*final_exam;

        double total_weight=hw_w+q_w+project_w+final_w;
        //toast
        if (total_weight != 100){
            Context context = getApplicationContext();
            CharSequence text = "Total Weight is not equal to 100%";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            grade_letter_img.setImageResource(R.drawable.aplus);
        }

        System.out.println(total_weight);
        final double avg =(hw+qs+project+final_exam)/total_weight *100;
        System.out.println(avg);
        avg_grade.setText(String.format("%.2f", avg));
        extr_credit.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked){
                avg_grade.setText(String.format("%.2f", avg+0.05));
                }
            else{
                avg_grade.setText(String.format("%.2f", avg));
            }
            }
        });

        if (avg>=90){
            grade_letter_img.setImageResource(R.drawable.aplus);
        }
        else if (avg>=80) {
            grade_letter_img.setImageResource(R.drawable.bplus);
        }
        else if(avg>=70){
            grade_letter_img.setImageResource(R.drawable.cplus);
        }
        else{
            grade_letter_img.setImageResource(R.drawable.gradef);
        }



    }
    public double addExtra(double avg){
        return avg+0.05;
    }

    public void restFields(){
        Spinner hw_spinner = (Spinner) findViewById(R.id.hw_spinner);

        EditText hw_grade = (EditText)findViewById(R.id.hw_grade);
        hw_grade.getText().clear();
        Spinner quizzes_spinner = (Spinner) findViewById(R.id.quizzes_spinner);
        EditText quizzes_grade = (EditText)findViewById(R.id.quizzes_grade);
        quizzes_grade.getText().clear();
        Spinner project_spinner = (Spinner) findViewById(R.id.project_spinner);
        EditText project_grade = (EditText)findViewById(R.id.project_grade);
        project_grade.getText().clear();
        Spinner final_spinner = (Spinner) findViewById(R.id.final_spinner);
        EditText final_grade = (EditText)findViewById(R.id.final_grade);
        final_grade.getText().clear();
        ImageView grade_letter_img = (ImageView) findViewById(R.id.imageView);
        final TextView avg_grade = (TextView) findViewById(R.id.avg_grade);

        Switch extra_credit = (Switch) findViewById(R.id.extra);
        extra_credit.setChecked(false);
        avg_grade.setText(String.format("%.2f", 0.0));
    }
}
