//
//  ViewController.swift
//  SmartHome
//
//  Created by Amjad Alharbi on 9/16/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let pink:UIColor=UIColor(colorLiteralRed: 233/255, green: 65/255, blue: 79/255, alpha: 1.0)
    
    func turn_on_off(img:UIImageView!,label:UILabel!,slider:UISlider!,isOn:Bool){
        if isOn{
            label.textColor=UIColor.black
            label.text=label.text?.uppercased()
            label.adjustsFontForContentSizeCategory=true
            img.alpha=1.0
            slider.isUserInteractionEnabled=true
            slider.tintColor=pink
        }
        else{
            label.textColor=UIColor.gray
            label.text=label.text?.lowercased()
            label.adjustsFontForContentSizeCategory=true
            img.alpha=0.5
            slider.isUserInteractionEnabled=false
            slider.tintColor=UIColor.gray
        }
    }
    @IBOutlet weak var seg_outlet: UISegmentedControl!
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var swit_status1: UISwitch!
    @IBOutlet weak var swit_status2: UISwitch!
    @IBOutlet weak var swit_status3: UISwitch!
    @IBOutlet weak var slider1: UISlider!
    @IBOutlet weak var slider2: UISlider!
    @IBOutlet weak var slider3: UISlider!
    
    @IBAction func turn_on1(_ sender: UISwitch) {
        turn_on_off(img: img1, label: label1, slider: slider1, isOn: swit_status1.isOn)
    }
    
    @IBAction func turn_on2(_ sender: UISwitch) {
        turn_on_off(img: img2, label: label2, slider: slider2, isOn: swit_status2.isOn)
    }
    
    
    @IBAction func turn_on3(_ sender: UISwitch) {
        turn_on_off(img: img3, label: label3, slider: slider3, isOn: swit_status3.isOn)
           }
    
    
    
    @IBAction func sliderchanged(_ sender: UISlider) {
        let fixed = roundf(sender.value / 5.0) * 5.0;
        sender.setValue(fixed, animated: true)
        if sender.tag==0{
            label1.font=UIFont(descriptor: label1.font.fontDescriptor, size: CGFloat(fixed+5))
            label1.adjustsFontSizeToFitWidth=true
        }
        else if sender.tag==1{
            label2.font=UIFont(descriptor: label2.font.fontDescriptor, size: CGFloat(fixed+5))
            label2.adjustsFontSizeToFitWidth=true
        }
        else if sender.tag==2{
              label3.font=UIFont(descriptor: label3.font.fontDescriptor, size: CGFloat(fixed+5))
            label1.adjustsFontSizeToFitWidth=true
        }
    }
    @IBAction func change_tab(_ sender: UISegmentedControl) {
        
        if seg_outlet.selectedSegmentIndex==0{
            label1.text="Kitchen"
            label2.text="Living Room"
            label3.text="Bedroom"
            img1.image=UIImage(named: "hanging_lights")
            img2.image=UIImage(named: "lamb")
            img3.image=UIImage(named: "light_bedroom")
            slider1.isHidden=false
            slider2.isHidden=false
            slider3.isHidden=false
            
            
        }
        else if seg_outlet.selectedSegmentIndex==1{
            label1.text="Cool"
            label2.text="Fan"
            label3.text="Heat"
            img1.image=UIImage(named: "AC")
            img2.image=UIImage(named: "fan")
            img3.image=UIImage(named: "heater")
            slider1.isHidden=false
            slider2.isHidden=false
            slider3.isHidden=false
            
        }
        else if seg_outlet.selectedSegmentIndex==2{
            label1.text="Front Door"
            label2.text="Patio Door"
            label3.text="Garage door"
            img1.image=UIImage(named: "door")
            img2.image=UIImage(named: "patio")
            img3.image=UIImage(named: "garage")
            slider1.isHidden=true
            slider2.isHidden=true
            slider3.isHidden=true
            
        }
    }
    

    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

