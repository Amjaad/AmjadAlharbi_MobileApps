package com.atlas.amjad.burrito;

/**
 * Created by amjad on 12/17/17.
 */

public class Place {
    private String place;
    private String URL;

    public void setPlaceInfo(Integer index){
        switch (index){
            case 0: //The Hill:
                place ="Illegal Petes";
                URL ="http://illegalpetes.com";
                break;
            case 1: //29th Street:
                place ="Chipotle";
                URL ="https://www.chipotle.com";
                break;
            case 2: //Bartaco
                place ="Bartaco";
                URL ="https://bartaco.com";
                break;

            default:
                place ="none";
                URL ="https://www.google.com/search?q=boulder+coffee+shops&ie=utf-8&oe=utf-8";
        }
    }



    public String getPlace(){

        return place;
    }

    public String getURL(){

        return URL;
    }
}
