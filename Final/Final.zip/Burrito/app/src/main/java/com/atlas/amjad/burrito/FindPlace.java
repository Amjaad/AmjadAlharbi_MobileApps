package com.atlas.amjad.burrito;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class FindPlace extends AppCompatActivity {
    private String Place;
    private String PlaceURL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_place);
        //get intent
        Intent intent = getIntent();
        Place = intent.getStringExtra("PlaceName");
        PlaceURL = intent.getStringExtra("URL");


//        //update text view
        TextView messageView = (TextView) findViewById(R.id.textView3);
        messageView.setText("You should check out " + Place);

//        //get image button
        final ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };

       // add listener to the button
        imageButton.setOnClickListener(onclick);
    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(PlaceURL));
        startActivity(intent);
    }
}
