package com.atlas.amjad.burrito;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    private Place my_place = new Place();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void builderButton(View view){
        EditText nameText = (EditText) findViewById(R.id.editText);
        String myname= nameText.getText().toString();
        Switch swit = (Switch) findViewById(R.id.switch1);


        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        String meat_or = "";
        if (toggle.isChecked()){
            meat_or  = "meat";
        }
        else {
            meat_or  = "veggie";
        }
        RadioGroup radio_group = (RadioGroup) findViewById(R.id.radioGroup);
        String type = "";
        ImageView img = (ImageView) findViewById(R.id.imageView);
        switch (radio_group.getCheckedRadioButtonId()){
            case R.id.radioButton1:type = "burrito";
            img.setImageResource(R.drawable.burrito);break;
            case R.id.radioButton2: type = "taco";
            img.setImageResource(R.drawable.taco);break;
            default: type="";
        }
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox);
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
        CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
        CheckBox checkBox4 = (CheckBox) findViewById(R.id.checkBox4);
        String checkboxStr = "";

        //(salsa, sour cream, cheese, guacamole
        if (checkBox1.isChecked()){
            checkboxStr += " salsa";
        }
        if(checkBox2.isChecked()){
            checkboxStr +=" sour cream";
        }
        if (checkBox3.isChecked()){
            checkboxStr+= " cheese";
        }
        if (checkBox4.isChecked()){
            checkboxStr+= " guacamole";
        }

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        String location= String.valueOf(spinner.getSelectedItem());


        TextView results= (TextView) findViewById(R.id.textView2);
        String gluten_free = "";


        results.setText("The " + myname + " is a "+type + " with "+meat_or +" with" + checkboxStr + " you'd like to eat on "+location);

        if (swit.isChecked()){
            gluten_free = "corn tortilla";
            results.setText("The " + myname + " is a "+type + " with "+meat_or +" with" + checkboxStr + " you'd like to eat on "+location+". You should try a corn tortilla");
        }


    }
    public void findBurrito(View view){
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        Integer i = spinner.getSelectedItemPosition();
         my_place.setPlaceInfo(i);
        Log.i("findBurrito",""+my_place.getPlace());

        String suggestedPlace = my_place.getPlace();

        String suggestedCoffeeShopURL =my_place.getURL();
//
        //create an Intent
        Intent intent = new Intent(this, FindPlace.class);
//
        //pass data
        intent.putExtra("PlaceName", suggestedPlace);
        intent.putExtra("URL", suggestedCoffeeShopURL);
//
        //start intent
        startActivity(intent);

    }
}
