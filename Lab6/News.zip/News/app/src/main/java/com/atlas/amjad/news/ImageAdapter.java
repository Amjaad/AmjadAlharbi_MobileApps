package com.atlas.amjad.news;

/**
 * Created by amjad on 11/22/17.
 */

import android.content.Context;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.Random;

public class ImageAdapter extends BaseAdapter {
    private Context mContext;

    public ImageAdapter(Context c) {
        mContext = c;
    }

    public int getCount() {
        return mThumbIds.length;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(480, 400));
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            imageView.setPadding(8, 16, 8, 16);
            imageView.setCropToPadding(true);
            imageView.setAdjustViewBounds(true);
            imageView.setBackgroundColor(Color.parseColor("#FFFFFF"));

        } else {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(mThumbIds[position]);
        return imageView;
    }

    // references to our images
    private Integer[] mThumbIds = {
            R.drawable.nyt, R.drawable.bloomberg,
            R.drawable.cnn, R.drawable.bbc,
            R.drawable.intercept,R.drawable.politico,
            R.drawable.verge, R.drawable.bbc_radio_icon
    };


}



