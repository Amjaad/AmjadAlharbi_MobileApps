package com.atlas.amjad.news;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GridView gridview = (GridView) findViewById(R.id.gridview);
        gridview.setAdapter(new ImageAdapter(this));
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
              if (position!=7){
                    loadWebSite(v,position);
                }
              else {
                 startPodcast(v);
              }

            }
        });


    }
    public void loadWebSite(View view, int position){
        Intent intent = new Intent(Intent.ACTION_VIEW);

        intent.setData(Uri.parse(getMediaURL(position)));
        startActivity(intent);
    }
    private String getMediaURL(int position){
        String url = "https://www.google.com/";
        switch (position){
            case 0: url="https://www.nytimes.com/";break;
            case 1: url="https://www.bloomberg.com/";break;
            case 2: url="http://www.cnn.com/"; break;
            case 3: url="https://www.bbc.com/news";break;
            case 4:url="https://theintercept.com/" ; break;
            case 5: url="https://www.politico.com/"; break;

            case 6: url="https://www.theverge.com/"; break;

        }
        return url;
    }

    /** Called when the user taps the Podcast Icon */
    public void startPodcast(View view) {
        Intent intent = new Intent(this, PodcastActivity.class);
        startActivity(intent);
    }
}
