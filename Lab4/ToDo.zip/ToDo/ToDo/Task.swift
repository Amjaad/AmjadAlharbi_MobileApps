//
//  Task.swift
//  ToDo
//
//  Created by Amjad Alharbi on 10/13/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import Foundation
class Task{
    var task_title:String?
    var dueDate:String?
    
}
