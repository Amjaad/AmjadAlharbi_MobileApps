//
//  Scene2ViewContoller.swift
//  ToDo
//
//  Created by Amjad Alharbi on 10/13/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import UIKit

class Scene2ViewContoller: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var user_task_input: UITextField!
    
    @IBOutlet weak var due_date_input: UITextField!
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "done_task"{
            let scene1ViewController = segue.destination as! ViewController
            //check to see that text was entered in the textfields
            if user_task_input.text!.isEmpty == false{
                scene1ViewController.user_task.task_title=user_task_input.text
            }
            if due_date_input.text!.isEmpty == false{
                scene1ViewController.user_task.dueDate=due_date_input.text
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad() {
        user_task_input.delegate=self
        due_date_input.delegate=self
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
