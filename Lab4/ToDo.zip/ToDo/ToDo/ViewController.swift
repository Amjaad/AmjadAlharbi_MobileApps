//
//  ViewController.swift
//  ToDo
//
//  Created by Amjad Alharbi on 10/13/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var due_date: UILabel!
    @IBOutlet weak var task: UILabel!
   
    var user_task=Task()
    let filename = "tasks.plist"
    
    @IBAction func unwindSegue (_ segue:UIStoryboardSegue){
        
        task.text=user_task.task_title
        due_date.text=user_task.dueDate
    }
    func docFilePath(_ filename: String) -> String?{
        //locate the documents directory
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.allDomainsMask, true)
        let dir = path[0] as NSString //document directory
        //creates the full path to our data file
        print(dir.appendingPathComponent(filename))
        return dir.appendingPathComponent(filename)
    }
    
    override func viewDidLoad() {
        let filePath = docFilePath(filename) //path to data file
        //if the data file exists, use it
        if FileManager.default.fileExists(atPath: filePath!){
            let path = filePath
            //load the data of the plist file into a dictionary
            let dataDictionary = NSDictionary(contentsOfFile: path!) as! [String:String]
            //load favorite book
            if dataDictionary.keys.contains("task") {
                user_task.task_title = dataDictionary["task"]
                task.text=user_task.task_title
            }
            //load favorite author
            if dataDictionary.keys.contains("dueDate") {
                user_task.dueDate = dataDictionary["dueDate"]
                due_date.text=user_task.dueDate
            }
        }
        
        //application instance
        let app = UIApplication.shared
        //subscribe to the UIApplicationWillResignActiveNotification notification
        NotificationCenter.default.addObserver(self, selector: #selector(UIApplicationDelegate.applicationWillResignActive(_:)), name: NSNotification.Name(rawValue: "UIApplicationWillResignActiveNotification"), object: app)
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func applicationWillResignActive(_ notification: Notification){
        let filePath = docFilePath(filename)
        let data = NSMutableDictionary()
        //adds
        if user_task.task_title != nil{
            data.setValue(user_task.task_title, forKey: "task")
            
        }
        if user_task.dueDate != nil{
            data.setValue(user_task.dueDate, forKey: "dueDate")
        }
        //write the contents of the array to our plist file
        data.write(toFile: filePath!, atomically: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

