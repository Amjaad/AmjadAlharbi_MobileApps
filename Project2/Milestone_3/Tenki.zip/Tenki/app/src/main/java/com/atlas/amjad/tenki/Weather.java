package com.atlas.amjad.tenki;



public class Weather {
    private int time;
    private String summary;
    private String icon;
    private double temperatureMin;
    private double temperatureMax;
    private double windSpeed;
    private double humidity;
    private double temperature;
    private String precipTyp;

    public void setPrecipTyp(String precipTyp) {
        this.precipTyp = precipTyp;
    }

    public String getPrecipTyp() {
        return precipTyp;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {

        this.temperature = convertTemp(temperature);
    }

    public Weather(){


    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public void setTemperatureMin(double temperatureMin) {
        this.temperatureMin = convertTemp(temperatureMin);
    }

    public void setTemperatureMax(double tempreatureMax) {
        this.temperatureMax = convertTemp(tempreatureMax);
    }

    public void setWindSpeed(double windSpeed) {
        this.windSpeed = windSpeed;
    }

    public void setHumidity(double humidity) {
        this.humidity = humidity;
    }

    public Weather(int time, String summary, String icon, double temperatureMin, double temperatureMax, double windSpeed, double humidity) {
        this.time = time;
        this.summary = summary;
        this.icon = icon;
        this.temperatureMin = temperatureMin;
        this.temperatureMax = temperatureMax;
        this.windSpeed = windSpeed;
        this.humidity = humidity;
    }

    public int getTime() {
        return time;
    }

    public String getSummary() {
        StringBuilder titleCase = new StringBuilder();
        boolean nextTitleCase = true;

        for (char c : summary.toCharArray()) {
            if (Character.isSpaceChar(c)) {
                nextTitleCase = true;
            } else if (nextTitleCase) {
                c = Character.toTitleCase(c);
                nextTitleCase = false;
            }

            titleCase.append(c);
        }

        return titleCase.toString();
    }

    public String getIcon() {
        return icon;
    }

    public double getTemperatureMin() {
        return temperatureMin;
    }

    public double getTemperatureMax() {
        return temperatureMax;
    }

    public double getWindSpeed() {
        return windSpeed;
    }

    public double getHumidity() {
        return humidity;
    }
    private double convertTemp(double t){
        return (t - 273.15) * 1.8 + 32;
    }
    public String formatTemp(double t){
        return String.format("%d°",(int)t);
    }
    public String getDetail(){
        return String.format("%2sFeels Like: %.1f° \n%2sHumidity: %.1f  \n%2sWind: %.1f mph"," ",temperature," ",humidity," ",windSpeed);
    }
    public String getTempRange(){
        return String.format("↑%d° ↓%d°",(int)temperatureMax,(int)temperatureMin);
    }
    public String getRecommendation (){
        if (precipTyp.equals("Rain")){
            return "You may want  to take an umbrella\n, since rain is expected";
        }
        else if(precipTyp.equals("Snow")){
            return "You may want to wear a coat, hat and gloves as well";
        }
        else if (temperatureMin <=25){
            return "Colder than yesterday. Be careful not to catch a cold.";
        }
        else if(getTemperatureMax()-getTemperatureMin()>=30){
            return "The temperature will change significantly, so plan accordingly,";
        }
        else if (precipTyp.equals("Clouds")){
            return "It will be cloudy until evening.";
        }


        if (humidity<30){
            return "It will be very dry, so stay hydrated";
        }
        else if (precipTyp.equals("Clear")){
            return "The weather today is sunny, don't forget the sunglasses";
       }

        return this.summary;
    }
    public String getForcast(){
        return String.format("High/Low: %s \n %2sWind: %.1f mph",getTempRange()," ",windSpeed);
    }
}