package com.atlas.amjad.tenki;

import android.content.Intent;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class FourDay extends AppCompatActivity {
    private Weather [] weatherList;

    private TextView day1,day2,day3,day4;
    private TextView msg1, msg2, msg3,msg4;
    private ImageView img1,img2,img3,img4;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_today:
                    Intent intent = new Intent(FourDay.this, MainActivity.class);
                    startActivity(intent);
                    return true;

                case R.id.navigation_four_day:
                    // Do nothing
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forcast);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        weatherList = new Weather[4];

        day1 = (TextView) findViewById(R.id.day1);
        day2 = (TextView) findViewById(R.id.day2);
        day3 = (TextView) findViewById(R.id.day3);
        day4 = (TextView) findViewById(R.id.day4);

        msg1 = (TextView)findViewById(R.id.msg1);
        msg2 = (TextView)findViewById(R.id.msg2);
        msg3 = (TextView)findViewById(R.id.msg3);
        msg4 = (TextView)findViewById(R.id.msg4);

        img1= (ImageView) findViewById(R.id.img1);
        img2= (ImageView) findViewById(R.id.img2);
        img3= (ImageView) findViewById(R.id.img3);
        img4= (ImageView) findViewById(R.id.img4);


        find_weather("Boulder");




    }
    public void find_weather(String city) {
        String url = "http://api.openweathermap.org/data/2.5/forecast?APPID=364905a321944dc78a0f61f41d66580b&q=" + city;

        JsonObjectRequest jor = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONArray array = response.getJSONArray("list");
                    Log.i("api","success");
                    for(int i =0 ; i<weatherList.length;i++){

                        JSONObject object = array.getJSONObject(i);
                        JSONObject main_object = object.getJSONObject("main");
                        JSONObject wind_object = object.getJSONObject("wind");
                        JSONArray weather_object = object.getJSONArray("weather");
                        weatherList[i]=new Weather();
                        weatherList[i].setTemperature(main_object.getDouble("temp"));
                        weatherList[i].setTemperatureMin(main_object.getDouble("temp_min"));
                        weatherList[i].setTemperatureMax(main_object.getDouble("temp_max"));
                        weatherList[i].setSummary(weather_object.getJSONObject(0).getString("description"));
                        weatherList[i].setIcon(weather_object.getJSONObject(0).getString("icon"));
                        weatherList[i].setHumidity(main_object.getDouble("humidity"));
                        weatherList[i].setWindSpeed(wind_object.getDouble("speed"));
                        weatherList[i].setPrecipTyp(weather_object.getJSONObject(0).getString("main"));
                        int resID = getResources().getIdentifier("i" + weatherList[i].getIcon().substring(0, 2) + "d", "drawable", getPackageName());
                            switch(i){
                                case 0: day1.setText(String.format("%2s %s"," ", getDate(object.getLong("dt"),i)));
                                        msg1.setText(String.format("%2s %s"," ",weatherList[i].getForcast()));
                                        img1.setImageResource(resID);break;

                                case 1: day2.setText(String.format("%2s %s"," ", getDate(object.getLong("dt"),i)));
                                        msg2.setText(String.format("%2s %s"," ",weatherList[i].getForcast()));
                                        img2.setImageResource(resID);break;

                                case 2: day3.setText(String.format("%2s %s"," ", getDate(object.getLong("dt"),i)));
                                        msg3.setText(String.format("%2s %s"," ",weatherList[i].getForcast()));
                                        img3.setImageResource(resID);
                                        break;

                                case 3: day4.setText(String.format("%2s %s"," ", getDate(object.getLong("dt"),i)));
                                        msg4.setText(String.format("%2s %s"," ",weatherList[i].getForcast()));
                                        img4.setImageResource(resID);
                                        break;
                            }




                    }




                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(jor);
    }
    private String getDate(long time, int i) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(time*1000L);
        if (i==5){
            c.add(Calendar.DATE,i);
        }
        else{
            c.add(Calendar.DATE,i+1);
        }
        Date d = c.getTime();

        return d.toString().substring(0,4);
    }

}