package com.atlas.amjad.tenki;


import android.content.Intent;

import android.location.LocationManager;
import android.os.Bundle;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;

import android.support.v7.app.AppCompatActivity;

import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;



import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity{
    private TextView temp, msg, detail, temp_range, summary;
    private Weather weather;
    private ImageView icon;
    private LocationManager locationManager;

    private String provider;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_today:
                    // Do nothing
                    return true;

                case R.id.navigation_four_day:
                    Intent intent = new Intent(MainActivity.this, FourDay.class);
                    startActivity(intent);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        temp = (TextView) findViewById(R.id.temp_now2);
        msg = (TextView) findViewById(R.id.textView4);
        detail = (TextView) findViewById(R.id.temp_now);
        temp_range = (TextView) findViewById(R.id.temp_range);
        TextView subtitle = (TextView) findViewById(R.id.details);
        subtitle.setText(String.format("%2s Detail", " "));
        summary = (TextView) findViewById(R.id.description);
        icon = (ImageView) findViewById(R.id.imageView3);
        msg = (TextView) findViewById(R.id.textView);
        weather = new Weather();
        String city = "Boulder";
        find_weather(city);


    }

    public void find_weather(String city) {
        String url = "http://api.openweathermap.org/data/2.5/weather?APPID=364905a321944dc78a0f61f41d66580b&q=" + city;

        JsonObjectRequest jor = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONObject main_object = response.getJSONObject("main");
                    JSONArray array = response.getJSONArray("weather");
                    JSONObject object = array.getJSONObject(0);

                    weather.setTemperature(main_object.getDouble("temp"));
                    weather.setTemperatureMin(main_object.getDouble("temp_min"));
                    weather.setTemperatureMax(main_object.getDouble("temp_max"));
                    weather.setSummary(object.getString("description"));
                    weather.setPrecipTyp(object.getString("main"));
                    weather.setIcon(object.getString("icon"));
                    weather.setHumidity(main_object.getDouble("humidity"));
                    temp.setText(weather.formatTemp(weather.getTemperature()));
                    detail.setText(weather.getDetail());
                    temp_range.setText(weather.getTempRange());
                    summary.setText(weather.getSummary());
                    weather.setWindSpeed(response.getJSONObject("wind").getDouble("speed"));
                    int resID = getResources().getIdentifier("i" + weather.getIcon().substring(0, 2) + "d", "drawable", getPackageName());
                    icon.setImageResource(resID);

                    msg.setText(weather.getRecommendation());



                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(jor);
    }


}
