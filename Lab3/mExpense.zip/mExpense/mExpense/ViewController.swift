//
//  ViewController.swift
//  mExpense
//
//  Created by Amjad Alharbi on 9/30/17.
//  Copyright © 2017 Amjad Alharbi. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var income: UITextField!
    @IBOutlet weak var rent: UITextField!
    @IBOutlet weak var groceries: UITextField!
    @IBOutlet weak var utilities: UITextField!
    
    @IBOutlet weak var total_expen: UILabel!
    @IBOutlet weak var balance: UILabel!
    
    
    @IBOutlet weak var precent_saved: UILabel!
    
    @IBOutlet weak var precent_spend: UILabel!
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func updateBalance(){
        var grocery_amount : Float
        var utilities_anmount : Float
        var rent_amount : Float
        
        if groceries.text!.isEmpty{
            grocery_amount=0.0
        }
        else{
            grocery_amount = Float(groceries.text!)!
        }
        if utilities.text!.isEmpty{
            utilities_anmount=0.0
        }
        else{
            utilities_anmount = Float(utilities.text!)!
        }
        if rent.text!.isEmpty{
            rent_amount=0.0
        }
        else{
            rent_amount = Float(rent.text!)!
        }
     
        let total = grocery_amount+rent_amount+utilities_anmount
        
        
        let currencyFormatter = NumberFormatter()
        currencyFormatter.numberStyle=NumberFormatter.Style.currency //set the number style
       total_expen.text=currencyFormatter.string(from: NSNumber(value:total))
        
        let income_amount = Float(income.text!)

        if income_amount == nil || (income_amount!)==0{
            let alert = UIAlertController(title: "Required Fields Missing", message: "You must enter your monthly income amount.", preferredStyle: .alert)
            let okAction=UIAlertAction(title: "OK", style:UIAlertActionStyle.cancel, handler: nil)
            alert.addAction(okAction) //adds the alert action to the alert object
            present(alert, animated: true, completion: nil)
            errorHighlightTextField(textField: income)
        }
        else{
            
            let balance_amount : Float = income_amount!-grocery_amount -  rent_amount -  utilities_anmount
            
            balance.text = currencyFormatter.string(from: NSNumber(value:balance_amount))
            
            let spent :Float = total/(income_amount!)*100
            let saved: Float = (income_amount!-total)/(income_amount!)*100
            
            precent_spend.text=String(format: "%.2f%%",spent) + " Spent"
            precent_saved.text=String(format: "%.2f%%", saved) + " Saved"
            removeErrorHighlightTextField(textField: income)
        }

        

     
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateBalance()
    }
    
    // Text Field is empty - show red border
    func errorHighlightTextField(textField: UITextField){
        textField.layer.borderColor = UIColor.red.cgColor
        textField.layer.borderWidth = 1
        textField.layer.cornerRadius = 5
    }
    func removeErrorHighlightTextField(textField: UITextField){
        textField.layer.borderColor = UIColor.gray.cgColor
        textField.layer.borderWidth = 0
        textField.layer.cornerRadius = 5
    }
    override func viewDidLoad() {
        income.delegate=self
        groceries.delegate=self
        rent.delegate=self
        utilities.delegate=self
        let tap = UITapGestureRecognizer(target: self, action: #selector(ViewController.closeKeyboard))
        view.addGestureRecognizer(tap)
        tap.cancelsTouchesInView = false
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
 
    }

    // Dismiss the keyboard by tapping the background
    func closeKeyboard() {
        view.endEditing(true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

